// extension/src/preferences.ts
var UI_PREFERENCES = "uiPreferences";
async function readPreferences(api) {
  const value = (await api.storage.local.get(UI_PREFERENCES))[UI_PREFERENCES];
  return { theme: value?.theme === "light" || value?.theme === "dark" ? value.theme : "system", currentTabOnly: value?.currentTabOnly === true };
}

// extension/src/theme.ts
var system = window.matchMedia("(prefers-color-scheme: dark)");
var choice = "system";
function apply() {
  document.documentElement.dataset.theme = choice === "system" ? system.matches ? "dark" : "light" : choice;
}
async function refresh() {
  try {
    choice = (await readPreferences(chrome)).theme;
  } catch {
    choice = "system";
  }
  apply();
}
apply();
void refresh();
system.addEventListener("change", apply);
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && UI_PREFERENCES in changes) void refresh();
});
