// extension/src/ui-client.ts
function element(id) {
  const node = document.getElementById(id);
  if (!node) throw new Error(`Missing UI element: ${id}`);
  return node;
}
function errorMessage(error) {
  return error instanceof Error ? error.message : "Something went wrong. Please try again.";
}
async function requestUi(request) {
  const response = await chrome.runtime.sendMessage(request);
  if (!response) throw new Error("The extension did not respond. Reload the extension and try again.");
  if (!response.ok) throw new Error(response.error);
  return response;
}
async function readState() {
  const result = await requestUi({ action: "state" });
  if (!result.state) throw new Error("The extension did not return its current state.");
  return result.state;
}
function showText(node, text) {
  node.textContent = text ?? "";
  node.hidden = !text;
}
function renderConnection(state2) {
  const status = element("connection-status");
  const dot = element("connection-dot");
  status.textContent = !state2.configured ? "Setup needed" : state2.connected ? "Connected to handoff server" : "Reconnecting to handoff server\u2026";
  dot.classList.toggle("online", state2.connected);
  dot.classList.toggle("offline", state2.configured && !state2.connected);
}
function startStatePolling(onState, onError, isBusy) {
  let inFlight = false;
  let disposed = false;
  const refresh = async () => {
    if (inFlight || disposed || isBusy()) return;
    inFlight = true;
    try {
      const state2 = await readState();
      if (!disposed && !isBusy()) onState(state2);
    } catch (error) {
      if (!disposed) onError(error);
    } finally {
      inFlight = false;
    }
  };
  void refresh();
  const timer = window.setInterval(() => {
    void refresh();
  }, 2e3);
  const stop = () => {
    disposed = true;
    window.clearInterval(timer);
  };
  window.addEventListener("pagehide", stop, { once: true });
  return stop;
}

// extension/src/pairing-ui.ts
function renderPairingRequests(node, requests, deviceId, busy2, act) {
  const signature = JSON.stringify([requests, deviceId, busy2]);
  if (node.dataset.rendered === signature) return;
  node.dataset.rendered = signature;
  node.replaceChildren(...requests.map((request) => {
    const incoming = request.destination.id === deviceId;
    const row = document.createElement("li");
    row.className = "pairing-request";
    const title = document.createElement("strong");
    title.textContent = incoming ? `${request.source.name} wants to pair` : `Request sent to ${request.destination.name}`;
    const detail = document.createElement("p");
    detail.className = "field-help";
    detail.textContent = `${incoming ? "Accept only if you recognize this browser. Pairing allows automatic incoming handoffs in both directions." : "Open Handoff on that browser and accept the request."} Expires at ${new Date(request.expiresAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}.`;
    row.append(title, detail);
    if (incoming) {
      const actions = document.createElement("div");
      actions.className = "pairing-actions";
      for (const [label, action] of [["Accept", "pairing.accept"], ["Decline", "pairing.decline"]]) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "secondary-button";
        button.textContent = label;
        button.disabled = busy2;
        button.setAttribute("aria-label", `${label} pairing with ${request.source.name}`);
        button.addEventListener("click", () => act({ action, requestId: request.id }));
        actions.append(button);
      }
      row.append(actions);
    }
    return row;
  }));
  node.hidden = requests.length === 0;
}

// extension/src/popup.ts
var destination = element("destination");
var handoff = element("handoff");
var errorBox = element("error");
var state;
var busy = false;
var actionError;
var pollError;
function render(next) {
  state = next;
  renderConnection(next);
  if (!busy) element("current-tab-only").checked = next.preferences?.currentTabOnly ?? false;
  element("current-tab-only").disabled = busy;
  renderPairingRequests(element("pairing-requests"), next.discovery?.requests ?? [], next.deviceId, busy, (action) => {
    void runAction(async () => {
      const result = await requestUi(action);
      if (result.state) state = result.state;
    });
  });
  element("welcome").hidden = next.configured;
  element("handoff-panel").hidden = !next.configured;
  element("device-name").textContent = next.name ?? "Classroom Handoff";
  const chosen = destination.value || next.preferredDestinationId || "";
  const options = next.devices.map((device) => {
    const option = document.createElement("option");
    option.value = device.id;
    option.textContent = `${device.name} \xB7 ${device.online ? "Online" : "Offline"}`;
    return option;
  });
  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = next.devices.length ? "Choose a device" : "No paired browsers yet";
  destination.replaceChildren(placeholder, ...options);
  const preferred = next.devices.some((d) => d.id === chosen) ? chosen : next.devices.some((d) => d.id === next.preferredDestinationId) ? next.preferredDestinationId : "";
  destination.value = preferred;
  destination.disabled = busy || next.devices.length === 0;
  const selected = next.devices.find((d) => d.id === preferred);
  element("destination-help").textContent = !next.devices.length ? "Choose Pair another browser to get started." : selected && !selected.online ? "This browser is offline. Reconnect it, then send again." : "The receiving browser opens your workspace automatically.";
  handoff.disabled = busy || !next.connected || !selected?.online || next.lastCommand?.status === "pending";
  handoff.querySelector("span").textContent = busy ? "Sending\u2026" : "Handoff";
  const commandBox = element("command-status");
  const command = next.lastCommand;
  commandBox.className = `notice ${command?.status ?? ""}`;
  const targetName = next.devices.find((d) => d.id === command?.destinationId)?.name ?? "the receiving browser";
  const statusText = command?.status === "pending" ? `Waiting for ${targetName} to apply your workspace. This is not yet confirmed.` : command?.status === "applied" ? `Workspace opened on ${targetName}.` : command?.status === "expired" ? "No acknowledgement arrived before this handoff expired. Check the receiving browser before sending again." : command?.status === "failed" ? `The receiving browser could not apply this handoff. ${command.error ?? "Please try again."}` : void 0;
  showText(commandBox, statusText);
  const warnings = [.../* @__PURE__ */ new Set([...next.captureWarnings ?? [], ...command?.warnings ?? []])];
  const warningList = element("capture-warnings");
  warningList.replaceChildren(...warnings.map((warning) => {
    const item = document.createElement("li");
    item.textContent = warning;
    return item;
  }));
  warningList.hidden = warnings.length === 0;
  const received = next.lastReceived;
  showText(element("received-status"), received ? `Last received from ${received.sourceName} at ${new Date(received.at).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}.${received.warnings.length ? ` ${received.warnings.join(" ")}` : ""}` : void 0);
  showText(errorBox, actionError || pollError || next.lastError);
}
async function runAction(action) {
  if (busy) return;
  busy = true;
  actionError = void 0;
  if (state) render(state);
  try {
    await action();
  } catch (error) {
    actionError = errorMessage(error);
  } finally {
    busy = false;
    if (state) render(state);
    else showText(errorBox, actionError);
  }
}
var openSetup = () => {
  void chrome.runtime.openOptionsPage().catch((error) => showText(errorBox, errorMessage(error)));
};
for (const id of ["open-settings", "start-setup", "manage-devices"]) element(id).addEventListener("click", openSetup);
element("pair-browser").addEventListener("click", () => {
  void chrome.tabs.create({ url: chrome.runtime.getURL("options.html#pair-browser") }).catch((error) => showText(errorBox, errorMessage(error)));
});
destination.addEventListener("change", () => {
  const deviceId = destination.value;
  if (!deviceId) {
    if (state) render(state);
    return;
  }
  void runAction(async () => {
    const result = await requestUi({ action: "destination", deviceId });
    if (result.state) state = result.state;
  });
});
element("current-tab-only").addEventListener("change", (event) => {
  const currentTabOnly = event.target.checked;
  void runAction(async () => {
    const result = await requestUi({ action: "preferences.update", currentTabOnly });
    if (result.state) state = result.state;
  });
});
handoff.addEventListener("click", () => {
  const destinationId = destination.value;
  if (!destinationId) return;
  void runAction(async () => {
    let source = await chrome.windows.getCurrent({ populate: false });
    if (source.type !== "normal") source = await chrome.windows.getLastFocused({ populate: false, windowTypes: ["normal"] });
    if (source.id === void 0 || source.type !== "normal") throw new Error("Open a normal browser window to send a workspace.");
    const result = await requestUi({ action: "handoff", destinationId, windowId: source.id, currentTabOnly: element("current-tab-only").checked });
    if (result.state) state = result.state;
    else if (result.command && state) state = { ...state, lastCommand: result.command };
  });
});
startStatePolling((next) => {
  pollError = void 0;
  render(next);
}, (error) => {
  pollError = errorMessage(error);
  showText(errorBox, actionError || pollError);
}, () => busy);
